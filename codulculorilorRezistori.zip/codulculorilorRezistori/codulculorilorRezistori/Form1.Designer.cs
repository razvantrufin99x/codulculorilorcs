﻿namespace codulculorilorRezistori
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.culoareactrl52 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl51 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl50 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl49 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl48 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl47 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl46 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl45 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl44 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl43 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl42 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl41 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl40 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl39 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl38 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl37 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl36 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl35 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl34 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl33 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl32 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl31 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl30 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl29 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl28 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl27 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl26 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl25 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl24 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl23 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl22 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl21 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl20 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl19 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl18 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl17 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl16 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl15 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl14 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl13 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl12 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl11 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl10 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl9 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl8 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl7 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl6 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl5 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl4 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl3 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl2 = new codulculorilorRezistori.culoareactrl();
            this.culoareactrl1 = new codulculorilorRezistori.culoareactrl();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(140, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 75;
            this.label1.Text = "A PRIMA CIFRA ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(215, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 76;
            this.label2.Text = "B A DOUA CIFRA";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(274, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 15);
            this.label3.TabIndex = 77;
            this.label3.Text = "C  COEFICIENT MULT 10E";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(347, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 15);
            this.label4.TabIndex = 78;
            this.label4.Text = "D TOLERANTA %";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(43, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 15);
            this.label6.TabIndex = 80;
            this.label6.Text = "NEGRU";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(43, 133);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 15);
            this.label7.TabIndex = 81;
            this.label7.Text = "MARO";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(43, 215);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 15);
            this.label8.TabIndex = 83;
            this.label8.Text = "PORTOCALIU";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(43, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 15);
            this.label9.TabIndex = 82;
            this.label9.Text = "ROSU";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(43, 381);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 15);
            this.label10.TabIndex = 87;
            this.label10.Text = "VIOLET";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(43, 340);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 15);
            this.label11.TabIndex = 86;
            this.label11.Text = "ALBASTRU";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(43, 299);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 15);
            this.label12.TabIndex = 85;
            this.label12.Text = "VERDE";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(43, 258);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 15);
            this.label13.TabIndex = 84;
            this.label13.Text = "GALBEN";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(40, 586);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 15);
            this.label17.TabIndex = 92;
            this.label17.Text = "FARA CULOARE";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(43, 545);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 15);
            this.label18.TabIndex = 91;
            this.label18.Text = "ARGINTIU";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(43, 504);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 15);
            this.label19.TabIndex = 90;
            this.label19.Text = "AURIU";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(43, 463);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(24, 15);
            this.label20.TabIndex = 89;
            this.label20.Text = "ALB";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(43, 422);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 15);
            this.label21.TabIndex = 88;
            this.label21.Text = "GRI";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(134, 54);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(61, 20);
            this.textBox1.TabIndex = 95;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(201, 54);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(61, 20);
            this.textBox2.TabIndex = 96;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(268, 54);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(61, 20);
            this.textBox3.TabIndex = 97;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(335, 54);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(61, 20);
            this.textBox4.TabIndex = 98;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(422, 159);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(149, 20);
            this.textBox6.TabIndex = 100;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(422, 185);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(149, 20);
            this.textBox7.TabIndex = 101;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(422, 211);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(149, 20);
            this.textBox8.TabIndex = 102;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(577, 218);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(34, 15);
            this.label14.TabIndex = 105;
            this.label14.Text = "MINIM";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(577, 192);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 15);
            this.label22.TabIndex = 104;
            this.label22.Text = "CENTRU";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(577, 162);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 15);
            this.label23.TabIndex = 103;
            this.label23.Text = "MAXIM";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(576, 258);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(103, 15);
            this.label24.TabIndex = 107;
            this.label24.Text = "VALOARE STANDARD";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(421, 251);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(149, 20);
            this.textBox9.TabIndex = 106;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(43, 41);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 15);
            this.label15.TabIndex = 108;
            this.label15.Text = "CULOARE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(422, 289);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 15);
            this.label5.TabIndex = 148;
            this.label5.Text = "E6";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(461, 289);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 15);
            this.label16.TabIndex = 149;
            this.label16.Text = "E12";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(509, 289);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(23, 15);
            this.label25.TabIndex = 150;
            this.label25.Text = "E24";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(605, 289);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(23, 15);
            this.label26.TabIndex = 153;
            this.label26.Text = "E96";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(557, 289);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(28, 15);
            this.label27.TabIndex = 152;
            this.label27.Text = "E148";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(605, 310);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(20, 15);
            this.label28.TabIndex = 158;
            this.label28.Text = "1%";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(557, 310);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(20, 15);
            this.label29.TabIndex = 157;
            this.label29.Text = "2%";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(509, 310);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(20, 15);
            this.label30.TabIndex = 156;
            this.label30.Text = "5%";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(461, 310);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(25, 15);
            this.label31.TabIndex = 155;
            this.label31.Text = "10%";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(422, 310);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(25, 15);
            this.label32.TabIndex = 154;
            this.label32.Text = "20%";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(649, 310);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(28, 15);
            this.label33.TabIndex = 160;
            this.label33.Text = "0.5%";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(649, 289);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(28, 15);
            this.label34.TabIndex = 159;
            this.label34.Text = "E192";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(422, 340);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(20, 15);
            this.label35.TabIndex = 161;
            this.label35.Text = "1.0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(464, 340);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(20, 15);
            this.label36.TabIndex = 162;
            this.label36.Text = "1.2";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(548, 340);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(20, 15);
            this.label37.TabIndex = 164;
            this.label37.Text = "1.8";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(506, 340);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(20, 15);
            this.label38.TabIndex = 163;
            this.label38.Text = "1.5";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(716, 340);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(20, 15);
            this.label39.TabIndex = 168;
            this.label39.Text = "3.9";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(674, 340);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(20, 15);
            this.label40.TabIndex = 167;
            this.label40.Text = "3.3";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(632, 340);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(20, 15);
            this.label41.TabIndex = 166;
            this.label41.Text = "2.7";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(590, 340);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(20, 15);
            this.label42.TabIndex = 165;
            this.label42.Text = "2.2";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(884, 340);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(20, 15);
            this.label43.TabIndex = 172;
            this.label43.Text = "8.2";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(842, 340);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(20, 15);
            this.label44.TabIndex = 171;
            this.label44.Text = "6.8";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(800, 340);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(20, 15);
            this.label45.TabIndex = 170;
            this.label45.Text = "5.6";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(758, 340);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(20, 15);
            this.label46.TabIndex = 169;
            this.label46.Text = "4.7";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(924, 310);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(49, 15);
            this.label47.TabIndex = 173;
            this.label47.Text = "STAS CEI";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(943, 340);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(18, 15);
            this.label48.TabIndex = 174;
            this.label48.Text = "E6";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(445, 359);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(20, 15);
            this.label49.TabIndex = 175;
            this.label49.Text = "1.1";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(487, 359);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(20, 15);
            this.label50.TabIndex = 176;
            this.label50.Text = "1.3";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(529, 359);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(20, 15);
            this.label51.TabIndex = 177;
            this.label51.Text = "1.6";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(905, 359);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(20, 15);
            this.label52.TabIndex = 186;
            this.label52.Text = "9.1";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(863, 359);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(20, 15);
            this.label53.TabIndex = 185;
            this.label53.Text = "7.5";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(821, 359);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(20, 15);
            this.label54.TabIndex = 184;
            this.label54.Text = "6.2";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(779, 359);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(20, 15);
            this.label55.TabIndex = 183;
            this.label55.Text = "5.1";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(737, 359);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(20, 15);
            this.label56.TabIndex = 182;
            this.label56.Text = "4.3";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(695, 359);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(20, 15);
            this.label57.TabIndex = 181;
            this.label57.Text = "3.6";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(653, 359);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(20, 15);
            this.label58.TabIndex = 180;
            this.label58.Text = "3.0";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(611, 359);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(20, 15);
            this.label59.TabIndex = 179;
            this.label59.Text = "2.4";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(569, 359);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(20, 15);
            this.label60.TabIndex = 178;
            this.label60.Text = "2.0";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(943, 359);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(23, 15);
            this.label61.TabIndex = 187;
            this.label61.Text = "E12";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(884, 359);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(20, 15);
            this.label62.TabIndex = 199;
            this.label62.Text = "8.2";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(842, 359);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(20, 15);
            this.label63.TabIndex = 198;
            this.label63.Text = "6.8";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(800, 359);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(20, 15);
            this.label64.TabIndex = 197;
            this.label64.Text = "5.6";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(758, 359);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(20, 15);
            this.label65.TabIndex = 196;
            this.label65.Text = "4.7";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(716, 359);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(20, 15);
            this.label66.TabIndex = 195;
            this.label66.Text = "3.9";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(674, 359);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(20, 15);
            this.label67.TabIndex = 194;
            this.label67.Text = "3.3";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(632, 359);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(20, 15);
            this.label68.TabIndex = 193;
            this.label68.Text = "2.7";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(590, 359);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(20, 15);
            this.label69.TabIndex = 192;
            this.label69.Text = "2.2";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(548, 359);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(20, 15);
            this.label70.TabIndex = 191;
            this.label70.Text = "1.8";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(506, 359);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(20, 15);
            this.label71.TabIndex = 190;
            this.label71.Text = "1.5";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(464, 359);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(20, 15);
            this.label72.TabIndex = 189;
            this.label72.Text = "1.2";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(422, 359);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(20, 15);
            this.label73.TabIndex = 188;
            this.label73.Text = "1.0";
            // 
            // culoareactrl52
            // 
            this.culoareactrl52.BackColor = System.Drawing.SystemColors.Control;
            this.culoareactrl52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.culoareactrl52.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl52.Location = new System.Drawing.Point(335, 574);
            this.culoareactrl52.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl52.Name = "culoareactrl52";
            this.culoareactrl52.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl52.TabIndex = 147;
            // 
            // culoareactrl51
            // 
            this.culoareactrl51.BackColor = System.Drawing.Color.Silver;
            this.culoareactrl51.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl51.Location = new System.Drawing.Point(335, 533);
            this.culoareactrl51.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl51.Name = "culoareactrl51";
            this.culoareactrl51.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl51.TabIndex = 146;
            // 
            // culoareactrl50
            // 
            this.culoareactrl50.BackColor = System.Drawing.Color.Gold;
            this.culoareactrl50.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl50.Location = new System.Drawing.Point(335, 492);
            this.culoareactrl50.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl50.Name = "culoareactrl50";
            this.culoareactrl50.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl50.TabIndex = 145;
            // 
            // culoareactrl49
            // 
            this.culoareactrl49.BackColor = System.Drawing.Color.White;
            this.culoareactrl49.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl49.Location = new System.Drawing.Point(335, 448);
            this.culoareactrl49.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl49.Name = "culoareactrl49";
            this.culoareactrl49.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl49.TabIndex = 144;
            // 
            // culoareactrl48
            // 
            this.culoareactrl48.BackColor = System.Drawing.Color.Gray;
            this.culoareactrl48.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl48.Location = new System.Drawing.Point(335, 408);
            this.culoareactrl48.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl48.Name = "culoareactrl48";
            this.culoareactrl48.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl48.TabIndex = 143;
            // 
            // culoareactrl47
            // 
            this.culoareactrl47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.culoareactrl47.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl47.Location = new System.Drawing.Point(335, 367);
            this.culoareactrl47.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl47.Name = "culoareactrl47";
            this.culoareactrl47.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl47.TabIndex = 142;
            // 
            // culoareactrl46
            // 
            this.culoareactrl46.BackColor = System.Drawing.Color.Blue;
            this.culoareactrl46.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl46.Location = new System.Drawing.Point(335, 326);
            this.culoareactrl46.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl46.Name = "culoareactrl46";
            this.culoareactrl46.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl46.TabIndex = 141;
            // 
            // culoareactrl45
            // 
            this.culoareactrl45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.culoareactrl45.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl45.Location = new System.Drawing.Point(335, 285);
            this.culoareactrl45.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl45.Name = "culoareactrl45";
            this.culoareactrl45.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl45.TabIndex = 140;
            // 
            // culoareactrl44
            // 
            this.culoareactrl44.BackColor = System.Drawing.Color.Yellow;
            this.culoareactrl44.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl44.Location = new System.Drawing.Point(335, 244);
            this.culoareactrl44.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl44.Name = "culoareactrl44";
            this.culoareactrl44.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl44.TabIndex = 139;
            // 
            // culoareactrl43
            // 
            this.culoareactrl43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.culoareactrl43.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl43.Location = new System.Drawing.Point(335, 203);
            this.culoareactrl43.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl43.Name = "culoareactrl43";
            this.culoareactrl43.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl43.TabIndex = 138;
            // 
            // culoareactrl42
            // 
            this.culoareactrl42.BackColor = System.Drawing.Color.Red;
            this.culoareactrl42.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl42.Location = new System.Drawing.Point(335, 162);
            this.culoareactrl42.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl42.Name = "culoareactrl42";
            this.culoareactrl42.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl42.TabIndex = 137;
            // 
            // culoareactrl41
            // 
            this.culoareactrl41.BackColor = System.Drawing.Color.Maroon;
            this.culoareactrl41.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl41.Location = new System.Drawing.Point(335, 121);
            this.culoareactrl41.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl41.Name = "culoareactrl41";
            this.culoareactrl41.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl41.TabIndex = 136;
            // 
            // culoareactrl40
            // 
            this.culoareactrl40.BackColor = System.Drawing.Color.Black;
            this.culoareactrl40.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl40.Location = new System.Drawing.Point(335, 80);
            this.culoareactrl40.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl40.Name = "culoareactrl40";
            this.culoareactrl40.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl40.TabIndex = 135;
            // 
            // culoareactrl39
            // 
            this.culoareactrl39.BackColor = System.Drawing.SystemColors.Control;
            this.culoareactrl39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.culoareactrl39.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl39.Location = new System.Drawing.Point(268, 574);
            this.culoareactrl39.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl39.Name = "culoareactrl39";
            this.culoareactrl39.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl39.TabIndex = 134;
            // 
            // culoareactrl38
            // 
            this.culoareactrl38.BackColor = System.Drawing.Color.Silver;
            this.culoareactrl38.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl38.Location = new System.Drawing.Point(268, 533);
            this.culoareactrl38.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl38.Name = "culoareactrl38";
            this.culoareactrl38.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl38.TabIndex = 133;
            // 
            // culoareactrl37
            // 
            this.culoareactrl37.BackColor = System.Drawing.Color.Gold;
            this.culoareactrl37.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl37.Location = new System.Drawing.Point(268, 492);
            this.culoareactrl37.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl37.Name = "culoareactrl37";
            this.culoareactrl37.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl37.TabIndex = 132;
            // 
            // culoareactrl36
            // 
            this.culoareactrl36.BackColor = System.Drawing.Color.White;
            this.culoareactrl36.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl36.Location = new System.Drawing.Point(268, 451);
            this.culoareactrl36.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl36.Name = "culoareactrl36";
            this.culoareactrl36.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl36.TabIndex = 131;
            // 
            // culoareactrl35
            // 
            this.culoareactrl35.BackColor = System.Drawing.Color.Gray;
            this.culoareactrl35.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl35.Location = new System.Drawing.Point(268, 408);
            this.culoareactrl35.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl35.Name = "culoareactrl35";
            this.culoareactrl35.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl35.TabIndex = 130;
            // 
            // culoareactrl34
            // 
            this.culoareactrl34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.culoareactrl34.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl34.Location = new System.Drawing.Point(268, 367);
            this.culoareactrl34.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl34.Name = "culoareactrl34";
            this.culoareactrl34.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl34.TabIndex = 129;
            // 
            // culoareactrl33
            // 
            this.culoareactrl33.BackColor = System.Drawing.Color.Blue;
            this.culoareactrl33.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl33.Location = new System.Drawing.Point(268, 326);
            this.culoareactrl33.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl33.Name = "culoareactrl33";
            this.culoareactrl33.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl33.TabIndex = 128;
            // 
            // culoareactrl32
            // 
            this.culoareactrl32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.culoareactrl32.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl32.Location = new System.Drawing.Point(268, 285);
            this.culoareactrl32.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl32.Name = "culoareactrl32";
            this.culoareactrl32.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl32.TabIndex = 127;
            // 
            // culoareactrl31
            // 
            this.culoareactrl31.BackColor = System.Drawing.Color.Yellow;
            this.culoareactrl31.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl31.Location = new System.Drawing.Point(268, 244);
            this.culoareactrl31.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl31.Name = "culoareactrl31";
            this.culoareactrl31.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl31.TabIndex = 126;
            // 
            // culoareactrl30
            // 
            this.culoareactrl30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.culoareactrl30.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl30.Location = new System.Drawing.Point(268, 203);
            this.culoareactrl30.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl30.Name = "culoareactrl30";
            this.culoareactrl30.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl30.TabIndex = 125;
            // 
            // culoareactrl29
            // 
            this.culoareactrl29.BackColor = System.Drawing.Color.Red;
            this.culoareactrl29.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl29.Location = new System.Drawing.Point(268, 162);
            this.culoareactrl29.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl29.Name = "culoareactrl29";
            this.culoareactrl29.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl29.TabIndex = 124;
            // 
            // culoareactrl28
            // 
            this.culoareactrl28.BackColor = System.Drawing.Color.Maroon;
            this.culoareactrl28.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl28.Location = new System.Drawing.Point(268, 121);
            this.culoareactrl28.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl28.Name = "culoareactrl28";
            this.culoareactrl28.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl28.TabIndex = 123;
            // 
            // culoareactrl27
            // 
            this.culoareactrl27.BackColor = System.Drawing.Color.Black;
            this.culoareactrl27.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl27.Location = new System.Drawing.Point(268, 80);
            this.culoareactrl27.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl27.Name = "culoareactrl27";
            this.culoareactrl27.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl27.TabIndex = 122;
            // 
            // culoareactrl26
            // 
            this.culoareactrl26.BackColor = System.Drawing.SystemColors.Control;
            this.culoareactrl26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.culoareactrl26.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl26.Location = new System.Drawing.Point(201, 574);
            this.culoareactrl26.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl26.Name = "culoareactrl26";
            this.culoareactrl26.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl26.TabIndex = 121;
            // 
            // culoareactrl25
            // 
            this.culoareactrl25.BackColor = System.Drawing.Color.Silver;
            this.culoareactrl25.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl25.Location = new System.Drawing.Point(201, 533);
            this.culoareactrl25.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl25.Name = "culoareactrl25";
            this.culoareactrl25.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl25.TabIndex = 120;
            // 
            // culoareactrl24
            // 
            this.culoareactrl24.BackColor = System.Drawing.Color.Gold;
            this.culoareactrl24.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl24.Location = new System.Drawing.Point(201, 492);
            this.culoareactrl24.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl24.Name = "culoareactrl24";
            this.culoareactrl24.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl24.TabIndex = 119;
            // 
            // culoareactrl23
            // 
            this.culoareactrl23.BackColor = System.Drawing.Color.White;
            this.culoareactrl23.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl23.Location = new System.Drawing.Point(201, 451);
            this.culoareactrl23.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl23.Name = "culoareactrl23";
            this.culoareactrl23.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl23.TabIndex = 118;
            // 
            // culoareactrl22
            // 
            this.culoareactrl22.BackColor = System.Drawing.Color.Gray;
            this.culoareactrl22.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl22.Location = new System.Drawing.Point(201, 408);
            this.culoareactrl22.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl22.Name = "culoareactrl22";
            this.culoareactrl22.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl22.TabIndex = 117;
            // 
            // culoareactrl21
            // 
            this.culoareactrl21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.culoareactrl21.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl21.Location = new System.Drawing.Point(201, 367);
            this.culoareactrl21.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl21.Name = "culoareactrl21";
            this.culoareactrl21.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl21.TabIndex = 116;
            // 
            // culoareactrl20
            // 
            this.culoareactrl20.BackColor = System.Drawing.Color.Blue;
            this.culoareactrl20.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl20.Location = new System.Drawing.Point(201, 326);
            this.culoareactrl20.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl20.Name = "culoareactrl20";
            this.culoareactrl20.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl20.TabIndex = 115;
            // 
            // culoareactrl19
            // 
            this.culoareactrl19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.culoareactrl19.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl19.Location = new System.Drawing.Point(201, 285);
            this.culoareactrl19.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl19.Name = "culoareactrl19";
            this.culoareactrl19.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl19.TabIndex = 114;
            // 
            // culoareactrl18
            // 
            this.culoareactrl18.BackColor = System.Drawing.Color.Yellow;
            this.culoareactrl18.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl18.Location = new System.Drawing.Point(201, 244);
            this.culoareactrl18.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl18.Name = "culoareactrl18";
            this.culoareactrl18.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl18.TabIndex = 113;
            // 
            // culoareactrl17
            // 
            this.culoareactrl17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.culoareactrl17.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl17.Location = new System.Drawing.Point(201, 203);
            this.culoareactrl17.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl17.Name = "culoareactrl17";
            this.culoareactrl17.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl17.TabIndex = 112;
            // 
            // culoareactrl16
            // 
            this.culoareactrl16.BackColor = System.Drawing.Color.Red;
            this.culoareactrl16.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl16.Location = new System.Drawing.Point(201, 162);
            this.culoareactrl16.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl16.Name = "culoareactrl16";
            this.culoareactrl16.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl16.TabIndex = 111;
            // 
            // culoareactrl15
            // 
            this.culoareactrl15.BackColor = System.Drawing.Color.Maroon;
            this.culoareactrl15.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl15.Location = new System.Drawing.Point(201, 121);
            this.culoareactrl15.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl15.Name = "culoareactrl15";
            this.culoareactrl15.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl15.TabIndex = 110;
            // 
            // culoareactrl14
            // 
            this.culoareactrl14.BackColor = System.Drawing.Color.Black;
            this.culoareactrl14.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl14.Location = new System.Drawing.Point(201, 80);
            this.culoareactrl14.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl14.Name = "culoareactrl14";
            this.culoareactrl14.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl14.TabIndex = 109;
            // 
            // culoareactrl13
            // 
            this.culoareactrl13.BackColor = System.Drawing.SystemColors.Control;
            this.culoareactrl13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.culoareactrl13.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl13.Location = new System.Drawing.Point(134, 574);
            this.culoareactrl13.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl13.Name = "culoareactrl13";
            this.culoareactrl13.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl13.TabIndex = 12;
            // 
            // culoareactrl12
            // 
            this.culoareactrl12.BackColor = System.Drawing.Color.Silver;
            this.culoareactrl12.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl12.Location = new System.Drawing.Point(134, 533);
            this.culoareactrl12.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl12.Name = "culoareactrl12";
            this.culoareactrl12.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl12.TabIndex = 11;
            // 
            // culoareactrl11
            // 
            this.culoareactrl11.BackColor = System.Drawing.Color.Gold;
            this.culoareactrl11.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl11.Location = new System.Drawing.Point(134, 492);
            this.culoareactrl11.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl11.Name = "culoareactrl11";
            this.culoareactrl11.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl11.TabIndex = 10;
            // 
            // culoareactrl10
            // 
            this.culoareactrl10.BackColor = System.Drawing.Color.White;
            this.culoareactrl10.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl10.Location = new System.Drawing.Point(134, 451);
            this.culoareactrl10.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl10.Name = "culoareactrl10";
            this.culoareactrl10.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl10.TabIndex = 9;
            // 
            // culoareactrl9
            // 
            this.culoareactrl9.BackColor = System.Drawing.Color.Gray;
            this.culoareactrl9.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl9.Location = new System.Drawing.Point(134, 408);
            this.culoareactrl9.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl9.Name = "culoareactrl9";
            this.culoareactrl9.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl9.TabIndex = 8;
            // 
            // culoareactrl8
            // 
            this.culoareactrl8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.culoareactrl8.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl8.Location = new System.Drawing.Point(134, 367);
            this.culoareactrl8.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl8.Name = "culoareactrl8";
            this.culoareactrl8.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl8.TabIndex = 7;
            // 
            // culoareactrl7
            // 
            this.culoareactrl7.BackColor = System.Drawing.Color.Blue;
            this.culoareactrl7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl7.Location = new System.Drawing.Point(134, 326);
            this.culoareactrl7.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl7.Name = "culoareactrl7";
            this.culoareactrl7.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl7.TabIndex = 6;
            // 
            // culoareactrl6
            // 
            this.culoareactrl6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.culoareactrl6.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl6.Location = new System.Drawing.Point(134, 285);
            this.culoareactrl6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl6.Name = "culoareactrl6";
            this.culoareactrl6.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl6.TabIndex = 5;
            // 
            // culoareactrl5
            // 
            this.culoareactrl5.BackColor = System.Drawing.Color.Yellow;
            this.culoareactrl5.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl5.Location = new System.Drawing.Point(134, 244);
            this.culoareactrl5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl5.Name = "culoareactrl5";
            this.culoareactrl5.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl5.TabIndex = 4;
            // 
            // culoareactrl4
            // 
            this.culoareactrl4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.culoareactrl4.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl4.Location = new System.Drawing.Point(134, 203);
            this.culoareactrl4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl4.Name = "culoareactrl4";
            this.culoareactrl4.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl4.TabIndex = 3;
            // 
            // culoareactrl3
            // 
            this.culoareactrl3.BackColor = System.Drawing.Color.Red;
            this.culoareactrl3.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl3.Location = new System.Drawing.Point(134, 162);
            this.culoareactrl3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl3.Name = "culoareactrl3";
            this.culoareactrl3.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl3.TabIndex = 2;
            // 
            // culoareactrl2
            // 
            this.culoareactrl2.BackColor = System.Drawing.Color.Maroon;
            this.culoareactrl2.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl2.Location = new System.Drawing.Point(134, 121);
            this.culoareactrl2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl2.Name = "culoareactrl2";
            this.culoareactrl2.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl2.TabIndex = 1;
            // 
            // culoareactrl1
            // 
            this.culoareactrl1.BackColor = System.Drawing.Color.Black;
            this.culoareactrl1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.culoareactrl1.Location = new System.Drawing.Point(134, 80);
            this.culoareactrl1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.culoareactrl1.Name = "culoareactrl1";
            this.culoareactrl1.Size = new System.Drawing.Size(61, 38);
            this.culoareactrl1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.culoareactrl52);
            this.Controls.Add(this.culoareactrl51);
            this.Controls.Add(this.culoareactrl50);
            this.Controls.Add(this.culoareactrl49);
            this.Controls.Add(this.culoareactrl48);
            this.Controls.Add(this.culoareactrl47);
            this.Controls.Add(this.culoareactrl46);
            this.Controls.Add(this.culoareactrl45);
            this.Controls.Add(this.culoareactrl44);
            this.Controls.Add(this.culoareactrl43);
            this.Controls.Add(this.culoareactrl42);
            this.Controls.Add(this.culoareactrl41);
            this.Controls.Add(this.culoareactrl40);
            this.Controls.Add(this.culoareactrl39);
            this.Controls.Add(this.culoareactrl38);
            this.Controls.Add(this.culoareactrl37);
            this.Controls.Add(this.culoareactrl36);
            this.Controls.Add(this.culoareactrl35);
            this.Controls.Add(this.culoareactrl34);
            this.Controls.Add(this.culoareactrl33);
            this.Controls.Add(this.culoareactrl32);
            this.Controls.Add(this.culoareactrl31);
            this.Controls.Add(this.culoareactrl30);
            this.Controls.Add(this.culoareactrl29);
            this.Controls.Add(this.culoareactrl28);
            this.Controls.Add(this.culoareactrl27);
            this.Controls.Add(this.culoareactrl26);
            this.Controls.Add(this.culoareactrl25);
            this.Controls.Add(this.culoareactrl24);
            this.Controls.Add(this.culoareactrl23);
            this.Controls.Add(this.culoareactrl22);
            this.Controls.Add(this.culoareactrl21);
            this.Controls.Add(this.culoareactrl20);
            this.Controls.Add(this.culoareactrl19);
            this.Controls.Add(this.culoareactrl18);
            this.Controls.Add(this.culoareactrl17);
            this.Controls.Add(this.culoareactrl16);
            this.Controls.Add(this.culoareactrl15);
            this.Controls.Add(this.culoareactrl14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.culoareactrl13);
            this.Controls.Add(this.culoareactrl12);
            this.Controls.Add(this.culoareactrl11);
            this.Controls.Add(this.culoareactrl10);
            this.Controls.Add(this.culoareactrl9);
            this.Controls.Add(this.culoareactrl8);
            this.Controls.Add(this.culoareactrl7);
            this.Controls.Add(this.culoareactrl6);
            this.Controls.Add(this.culoareactrl5);
            this.Controls.Add(this.culoareactrl4);
            this.Controls.Add(this.culoareactrl3);
            this.Controls.Add(this.culoareactrl2);
            this.Controls.Add(this.culoareactrl1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Codul culorilor pentru Rezistori";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private culoareactrl culoareactrl1;
        private culoareactrl culoareactrl2;
        private culoareactrl culoareactrl3;
        private culoareactrl culoareactrl4;
        private culoareactrl culoareactrl5;
        private culoareactrl culoareactrl6;
        private culoareactrl culoareactrl7;
        private culoareactrl culoareactrl8;
        private culoareactrl culoareactrl9;
        private culoareactrl culoareactrl10;
        private culoareactrl culoareactrl11;
        private culoareactrl culoareactrl12;
        private culoareactrl culoareactrl13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label15;
        private culoareactrl culoareactrl14;
        private culoareactrl culoareactrl15;
        private culoareactrl culoareactrl16;
        private culoareactrl culoareactrl17;
        private culoareactrl culoareactrl18;
        private culoareactrl culoareactrl19;
        private culoareactrl culoareactrl20;
        private culoareactrl culoareactrl21;
        private culoareactrl culoareactrl22;
        private culoareactrl culoareactrl23;
        private culoareactrl culoareactrl24;
        private culoareactrl culoareactrl25;
        private culoareactrl culoareactrl26;
        private culoareactrl culoareactrl27;
        private culoareactrl culoareactrl28;
        private culoareactrl culoareactrl29;
        private culoareactrl culoareactrl30;
        private culoareactrl culoareactrl31;
        private culoareactrl culoareactrl32;
        private culoareactrl culoareactrl33;
        private culoareactrl culoareactrl34;
        private culoareactrl culoareactrl35;
        private culoareactrl culoareactrl36;
        private culoareactrl culoareactrl37;
        private culoareactrl culoareactrl38;
        private culoareactrl culoareactrl39;
        private culoareactrl culoareactrl40;
        private culoareactrl culoareactrl41;
        private culoareactrl culoareactrl42;
        private culoareactrl culoareactrl43;
        private culoareactrl culoareactrl44;
        private culoareactrl culoareactrl45;
        private culoareactrl culoareactrl46;
        private culoareactrl culoareactrl47;
        private culoareactrl culoareactrl48;
        private culoareactrl culoareactrl49;
        private culoareactrl culoareactrl50;
        private culoareactrl culoareactrl51;
        private culoareactrl culoareactrl52;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
    }
}

